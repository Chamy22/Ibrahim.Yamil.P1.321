/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package baseespacial;

/**
 *
 * @author yamil
 */
public class Robot extends UnidadOperativa implements Movible {
    private int autonomiaHoras;

    public Robot(String nombre, String modulo, TipoAtmosfera tipoAtmosfera, int autonomiaHoras) {
        super(nombre, modulo, tipoAtmosfera);
        this.autonomiaHoras = autonomiaHoras;
    }

    @Override
    public void mover(String nuevoModulo) {
        System.out.println("Robot " + nombre + " se desplaza de " + modulo + " a " + nuevoModulo + ".");
        this.modulo = nuevoModulo;
    }

    @Override
    public void replicarse() {
        System.out.println("Robot " + nombre + " se replica mediante copia.");
    }

    @Override
    public String mostrar() {
        return "Robot - Nombre: " + nombre + ", Módulo: " + modulo + ", Atmósfera: " + tipoAtmosfera
                + ", Autonomía: " + autonomiaHoras + " h";
    }
}

