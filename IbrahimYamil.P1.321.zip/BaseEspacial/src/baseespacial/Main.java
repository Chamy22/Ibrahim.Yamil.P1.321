package baseespacial;

import baseespacial.Astronauta;
import baseespacial.Experimento;
import baseespacial.TipoAtmosfera;
import baseespacial.Robot;

public class Main {

    public static void main(String[] args) {
        BaseEspacial base = new BaseEspacial321();

        base.agregarUnidadOperativa(new Astronauta("Cmdr. Vega", "M1", TipoAtmosfera.PRESURIZADA, 6));
        base.agregarUnidadOperativa(new Robot("XR-12", "M2", TipoAtmosfera.VACIO, 24));
        base.agregarUnidadOperativa(new Experimento("Fotosíntesis-Lab", "M1", TipoAtmosfera.PRESURIZADA, 30));

        System.out.println("\n-- Mostrar Unidades --");
        base.mostrarUnidades();

        System.out.println("\n-- Mover Unidades a M3 --");
        base.moverUnidades("M3");

        System.out.println("\n-- Realizar Funciones Base --");
        base.realizarFuncionesBase();

        System.out.println("\n-- Filtrar por atmósfera PRESURIZADA --");
        base.filtrarPorTipoAtmosfera(TipoAtmosfera.PRESURIZADA);
    }
}
