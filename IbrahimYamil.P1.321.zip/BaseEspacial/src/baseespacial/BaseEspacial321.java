

package baseespacial;


import java.util.*;
import java.util.stream.Collectors;

public class BaseEspacial321 {
    private final List<UnidadOperativa> unidades = new ArrayList<>();

    public void agregarUnidadOperativa(UnidadOperativa nueva) throws UnidadDuplicadaException {
        boolean existe = unidades.stream()
            .anyMatch(u -> u.getNombre().equalsIgnoreCase(nueva.getNombre())
                        && u.getModulo().equalsIgnoreCase(nueva.getModulo()));
        if (existe) {
            throw new UnidadDuplicadaException("Conflicto: ya existe una unidad con nombre '" 
                + nueva.getNombre() + "' en el módulo '" + nueva.getModulo() + "'.");
        }
        unidades.add(nueva);
    }

    public void mostrarUnidades() {
        unidades.forEach(u -> System.out.println(u.mostrar()));
    }

    public void moverUnidades(String moduloDestinoPorDefecto) {
        for (UnidadOperativa u : unidades) {
            if (u instanceof Movible movible) {
                movible.mover(moduloDestinoPorDefecto);
            } else {
                System.out.println("La unidad " + u.getNombre() + " (Experimento) no puede moverse.");
            }
        }
    }

    public void realizarFuncionesBase() {
        unidades.forEach(UnidadOperativa::realizarFuncionesBase);
    }

    public void filtrarPorTipoAtmosfera(TipoAtmosfera tipo) {
        List<UnidadOperativa> filtradas = unidades.stream()
            .filter(u -> u.getTipoAtmosfera() == tipo)
            .collect(Collectors.toList());
        if (filtradas.isEmpty()) {
            System.out.println("No hay unidades para la atmósfera " + tipo);
        } else {
            filtradas.forEach(u -> System.out.println(u.mostrar()));
        }
    }
}

