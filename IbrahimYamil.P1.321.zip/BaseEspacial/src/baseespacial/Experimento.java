/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package baseespacial;

/**
 *
 * @author yamil
 */
public class Experimento extends UnidadOperativa {
    private int duracionIdealDias;

    public Experimento(String nombre, String modulo, TipoAtmosfera tipoAtmosfera, int duracionIdealDias) {
        super(nombre, modulo, tipoAtmosfera);
        this.duracionIdealDias = duracionIdealDias;
    }

    @Override
    public void replicarse() {
        System.out.println("Experimento " + nombre + " se replica por clonación de protocolo.");
    }

    @Override
    public String mostrar() {
        return "Experimento - Nombre: " + nombre + ", Módulo: " + modulo + ", Atmósfera: " + tipoAtmosfera
                + ", Duración ideal: " + duracionIdealDias + " días";
    }
}
