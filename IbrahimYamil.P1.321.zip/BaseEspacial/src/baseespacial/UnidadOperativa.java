/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package baseespacial;

/**
 *
 * @author yamil
 */
public abstract class UnidadOperativa {
    String nombre;
    String modulo;
    TipoAtmosfera tipoAtmosfera;

    public UnidadOperativa(String nombre, String modulo, TipoAtmosfera tipoAtmosfera) {
        if (nombre == null || nombre.isEmpty()){ 
            throw new IllegalArgumentException("Nombre inválido");}
        if (modulo == null || modulo.isEmpty()) {
            throw new IllegalArgumentException("Módulo inválido");
        }

        this.nombre = nombre;
        this.modulo = modulo;
        this.tipoAtmosfera = tipoAtmosfera;
    }

    public String getNombre() {
        return nombre;
    }

    public String getModulo() {
        return modulo;
    }

    public TipoAtmosfera getTipoAtmosfera() {
        return tipoAtmosfera;
    }
    
    public void realizarFuncionesBase(){
        reabastecer();
        mantenerAtmosfera();
        replicarse();
    }
    public void reabastecer() {
        System.out.println(nombre + " se reabastece.");
    }

    public void mantenerAtmosfera() {
        System.out.println(nombre + " mantiene las condiciones atmosféricas (" + tipoAtmosfera + ").");
    }

    public abstract void replicarse();

    public abstract String mostrar();
}

    

