/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package baseespacial;

/**
 *
 * @author yamil
 */
public class Astronauta extends UnidadOperativa implements Movible {
    private int horasMaxEVA;

    public Astronauta(String nombre, String modulo, TipoAtmosfera tipoAtmosfera, int horasMaxEVA) {
        super(nombre, modulo, tipoAtmosfera);
        if (horasMaxEVA < 0) {
            throw new IllegalArgumentException("Horas EVA inválidas");
        }
        this.horasMaxEVA = horasMaxEVA;
    }

    @Override
    public void mover(String nuevoModulo) {
        System.out.println("Astronauta " + nombre + " se desplaza de " + modulo + " a " + nuevoModulo + ".");
        this.modulo = nuevoModulo;
    }

    @Override
    public void replicarse() {
        System.out.println("Astronauta " + nombre + " se replica mediante entrenamiento.");
    }

    @Override
    public String mostrar() {
        return "Astronauta - Nombre: " + nombre + ", Módulo: " + modulo + ", Atmósfera: " + tipoAtmosfera
                + ", Horas EVA: " + horasMaxEVA;
    }
}

